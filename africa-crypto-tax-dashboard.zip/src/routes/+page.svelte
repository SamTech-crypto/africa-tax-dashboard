<script lang="ts">
	import { onMount } from 'svelte';
	import { DollarSign, TrendingDown, TrendingUp, AlertTriangle, CheckCircle } from 'lucide-svelte';

	// Svelte 5 runes for reactive state
	let monthlyVolume = $state('');
	let selectedCountry = $state('Nigeria');
	let currentStructure = $state('Direct exchange → local bank');

	let usdcRate = $state<number | null>(null);
	let lastUpdate = $state(new Date());
	let loading = $state(true);

	const countryData = {
		Nigeria: {
			flag: '🇳🇬',
			currency: 'NGN',
			exchangeRate: 1650,
			vat: 7.5,
			withholdingTax: 10,
			capitalGains: 10,
			digitalServicesTax: 6,
			psc: 0,
			optimizedRate: 2.5
		},
		Kenya: {
			flag: '🇰🇪',
			currency: 'KES',
			exchangeRate: 129,
			vat: 16,
			withholdingTax: 5,
			capitalGains: 5,
			digitalServicesTax: 1.5,
			psc: 0,
			optimizedRate: 3.0
		},
		Ghana: {
			flag: '🇬🇭',
			currency: 'GHS',
			exchangeRate: 15.2,
			vat: 15,
			withholdingTax: 3,
			capitalGains: 0,
			digitalServicesTax: 0,
			psc: 0,
			optimizedRate: 1.5
		},
		'South Africa': {
			flag: '🇿🇦',
			currency: 'ZAR',
			exchangeRate: 18.5,
			vat: 15,
			withholdingTax: 15,
			capitalGains: 18,
			digitalServicesTax: 0,
			psc: 0,
			optimizedRate: 4.5
		},
		Egypt: {
			flag: '🇪🇬',
			currency: 'EGP',
			exchangeRate: 49.5,
			vat: 14,
			withholdingTax: 10,
			capitalGains: 10,
			digitalServicesTax: 0,
			psc: 0,
			optimizedRate: 3.0
		},
		Uganda: {
			flag: '🇺🇬',
			currency: 'UGX',
			exchangeRate: 3750,
			vat: 18,
			withholdingTax: 0,
			capitalGains: 0,
			digitalServicesTax: 5,
			psc: 0,
			optimizedRate: 0.5
		},
		Rwanda: {
			flag: '🇷🇼',
			currency: 'RWF',
			exchangeRate: 1350,
			vat: 18,
			withholdingTax: 15,
			capitalGains: 0,
			digitalServicesTax: 0,
			psc: 0,
			optimizedRate: 2.0
		},
		Tanzania: {
			flag: '🇹🇿',
			currency: 'TZS',
			exchangeRate: 2550,
			vat: 18,
			withholdingTax: 15,
			capitalGains: 10,
			digitalServicesTax: 2,
			psc: 0,
			optimizedRate: 3.5
		},
		Mauritius: {
			flag: '🇲🇺',
			currency: 'MUR',
			exchangeRate: 46.5,
			vat: 15,
			withholdingTax: 0,
			capitalGains: 0,
			digitalServicesTax: 0,
			psc: 3,
			optimizedRate: 0.8
		}
	};

	const structures = [
		'Direct exchange → local bank',
		'Exchange → local fintech partner',
		'Stablecoin → CEX → local ramp',
		'DeFi → local on-ramp'
	];

	const structureMultipliers = {
		'Direct exchange → local bank': 1.0,
		'Exchange → local fintech partner': 0.85,
		'Stablecoin → CEX → local ramp': 0.7,
		'DeFi → local on-ramp': 0.6
	};

	let historicalData = $state<any[]>([]);

	onMount(() => {
		// Fetch live USDC price
		const fetchPrice = async () => {
			try {
				const response = await fetch(
					'https://api.coingecko.com/api/v3/simple/price?ids=usd-coin&vs_currencies=usd'
				);
				const data = await response.json();
				usdcRate = data['usd-coin'].usd;
				lastUpdate = new Date();
				loading = false;
			} catch (error) {
				console.error('Error fetching price:', error);
				usdcRate = 1.0;
				loading = false;
			}
		};

		fetchPrice();
		const interval = setInterval(fetchPrice, 30000);

		// Generate 7-day historical data
		const data = [];
		for (let i = 6; i >= 0; i--) {
			const date = new Date();
			date.setDate(date.getDate() - i);
			data.push({
				date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
				exposure: Math.random() * 15000 + 5000
			});
		}
		historicalData = data;

		return () => clearInterval(interval);
	});

	const tax = $derived.by(() => {
		const volume = parseFloat(monthlyVolume) || 0;
		if (volume === 0) return { current: 0, optimized: 0, savings: 0, currentRate: 0, optimizedRate: 0 };

		const country = countryData[selectedCountry as keyof typeof countryData];
		const multiplier = structureMultipliers[currentStructure as keyof typeof structureMultipliers];

		let currentTaxRate = 0;
		currentTaxRate += country.vat;
		currentTaxRate += country.withholdingTax;
		currentTaxRate += country.capitalGains;
		currentTaxRate += country.digitalServicesTax;
		currentTaxRate += country.psc;

		currentTaxRate = currentTaxRate * multiplier;

		const optimizedTaxRate = country.optimizedRate;

		const currentTax = volume * (currentTaxRate / 100);
		const optimizedTax = volume * (optimizedTaxRate / 100);
		const savings = currentTax - optimizedTax;

		return {
			current: currentTax,
			optimized: optimizedTax,
			savings: savings,
			currentRate: currentTaxRate,
			optimizedRate: optimizedTaxRate
		};
	});

	const country = $derived(countryData[selectedCountry as keyof typeof countryData]);

	function formatUSD(num: number) {
		return new Intl.NumberFormat('en-US', {
			style: 'currency',
			currency: 'USD',
			minimumFractionDigits: 0,
			maximumFractionDigits: 0
		}).format(num);
	}

	function formatPercent(num: number) {
		return `${num.toFixed(1)}%`;
	}
</script>

<div class="min-h-screen bg-black text-white p-4 md:p-8">
	<div class="max-w-7xl mx-auto">
		<!-- Header -->
		<div class="mb-8">
			<h1 class="text-4xl md:text-5xl font-bold mb-2 bg-gradient-to-r from-green-400 via-emerald-500 to-teal-400 bg-clip-text text-transparent">
				Africa Crypto Tax Leakage Dashboard
			</h1>
			<p class="text-gray-400 text-lg">Real-time tax optimization for Web3 businesses in Africa</p>
		</div>

		<!-- Input Section -->
		<div
			class="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 md:p-8 mb-6 border border-green-500/30 shadow-2xl shadow-green-500/10"
		>
			<div class="grid grid-cols-1 md:grid-cols-3 gap-6">
				<!-- Volume Input -->
				<div class="md:col-span-3">
					<label for="monthly-volume" class="block text-sm font-medium text-gray-300 mb-2">
						💰 Monthly Africa Volume (USDC/USDT)
					</label>
					<div class="relative">
						<DollarSign class="absolute left-4 top-1/2 transform -translate-y-1/2 text-green-400 w-6 h-6" />
						<input
							id="monthly-volume"
							type="number"
							bind:value={monthlyVolume}
							placeholder="5000000"
							class="w-full bg-black/50 border-2 border-green-500/50 rounded-xl px-12 py-4 text-2xl font-bold text-white placeholder-gray-600 focus:outline-none focus:border-green-400 transition-all"
						/>
					</div>
				</div>

				<!-- Country Dropdown -->
				<div>
					<label for="country-select" class="block text-sm font-medium text-gray-300 mb-2">
						🌍 Select Country
					</label>
					<select
						id="country-select"
						bind:value={selectedCountry}
						class="w-full bg-black/50 border-2 border-green-500/50 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-green-400 transition-all cursor-pointer"
					>
						{#each Object.entries(countryData) as [countryName, data]}
							<option value={countryName}>
								{data.flag} {countryName}
							</option>
						{/each}
					</select>
				</div>

				<!-- Structure Dropdown -->
				<div class="md:col-span-2">
					<label for="structure-select" class="block text-sm font-medium text-gray-300 mb-2">
						🏗️ Current Structure
					</label>
					<select
						id="structure-select"
						bind:value={currentStructure}
						class="w-full bg-black/50 border-2 border-green-500/50 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-green-400 transition-all cursor-pointer"
					>
						{#each structures as structure}
							<option value={structure}>{structure}</option>
						{/each}
					</select>
				</div>
			</div>
		</div>

		<!-- Real-time Section -->
		<div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
			<!-- Live USDC Rate -->
			<div class="bg-gradient-to-br from-green-900/40 to-green-800/40 rounded-2xl p-6 border border-green-500/30 relative overflow-hidden">
				<div class="absolute top-0 right-0 w-32 h-32 bg-green-400/10 rounded-full blur-3xl"></div>
				<div class="relative">
					<div class="flex items-center justify-between mb-2">
						<h3 class="text-sm font-medium text-gray-300">Live USDC Rate</h3>
						<div
							class={`w-2 h-2 rounded-full ${loading ? 'bg-yellow-400' : 'bg-green-400'} animate-pulse`}
						></div>
					</div>
					<div class="text-4xl font-bold text-green-400 mb-1">
						${usdcRate ? usdcRate.toFixed(4) : '1.0000'}
					</div>
					<div class="text-sm text-gray-400">
						Last update: {lastUpdate.toLocaleTimeString()}
					</div>
					<div class="mt-3 text-xs text-gray-500">
						Source: CoinGecko API
					</div>
				</div>
			</div>

			<!-- Local Currency Rate -->
			<div class="bg-gradient-to-br from-blue-900/40 to-blue-800/40 rounded-2xl p-6 border border-blue-500/30 relative overflow-hidden">
				<div class="absolute top-0 right-0 w-32 h-32 bg-blue-400/10 rounded-full blur-3xl"></div>
				<div class="relative">
					<div class="flex items-center justify-between mb-2">
						<h3 class="text-sm font-medium text-gray-300">USDC → {country.currency}</h3>
						<span class="text-2xl">{country.flag}</span>
					</div>
					<div class="text-4xl font-bold text-blue-400 mb-1">
						{country.exchangeRate.toLocaleString()} {country.currency}
					</div>
					<div class="text-sm text-gray-400">
						1 USDC = {country.exchangeRate} {country.currency}
					</div>
					<div class="mt-3 text-xs text-gray-500">
						Interbank rate (2025)
					</div>
				</div>
			</div>
		</div>

		<!-- Tax Breakdown Card -->
		<div class="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 mb-6 border border-yellow-500/30">
			<h3 class="text-xl font-bold mb-4 text-yellow-400 flex items-center gap-2">
				<AlertTriangle class="w-5 h-5" />
				{selectedCountry} Tax Rates 2025
			</h3>
			<div class="grid grid-cols-2 md:grid-cols-5 gap-4">
				<div class="bg-black/30 rounded-lg p-3">
					<div class="text-xs text-gray-400 mb-1">VAT</div>
					<div class="text-xl font-bold text-red-400">{formatPercent(country.vat)}</div>
				</div>
				<div class="bg-black/30 rounded-lg p-3">
					<div class="text-xs text-gray-400 mb-1">Withholding</div>
					<div class="text-xl font-bold text-red-400">{formatPercent(country.withholdingTax)}</div>
				</div>
				<div class="bg-black/30 rounded-lg p-3">
					<div class="text-xs text-gray-400 mb-1">Capital Gains</div>
					<div class="text-xl font-bold text-red-400">{formatPercent(country.capitalGains)}</div>
				</div>
				<div class="bg-black/30 rounded-lg p-3">
					<div class="text-xs text-gray-400 mb-1">Digital Services</div>
					<div class="text-xl font-bold text-red-400">{formatPercent(country.digitalServicesTax)}</div>
				</div>
				<div class="bg-black/30 rounded-lg p-3">
					<div class="text-xs text-gray-400 mb-1">PSC</div>
					<div class="text-xl font-bold text-red-400">{formatPercent(country.psc)}</div>
				</div>
			</div>
		</div>

		<!-- Output Table - Big Numbers -->
		{#if monthlyVolume && parseFloat(monthlyVolume) > 0}
			<div
				class="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-8 mb-6 border-2 border-green-500/50 shadow-2xl shadow-green-500/20"
			>
				<h2 class="text-2xl font-bold mb-6 text-center text-green-400">
					💎 Tax Impact Analysis
				</h2>

				<div class="space-y-6">
					<!-- Current Tax -->
					<div class="bg-red-900/20 border-2 border-red-500/50 rounded-xl p-6">
						<div class="flex items-start justify-between">
							<div>
								<div class="text-sm text-gray-400 mb-2">❌ Tax Paid TODAY (Current Structure)</div>
								<div class="text-5xl font-bold text-red-400 mb-2">{formatUSD(tax.current)}</div>
								<div class="text-xl text-red-300">{formatPercent(tax.currentRate)} effective rate</div>
							</div>
							<TrendingDown class="w-12 h-12 text-red-400" />
						</div>
					</div>

					<!-- Optimized Tax -->
					<div class="bg-green-900/20 border-2 border-green-500/50 rounded-xl p-6">
						<div class="flex items-start justify-between">
							<div>
								<div class="text-sm text-gray-400 mb-2">✅ Tax with Optimized Structure</div>
								<div class="text-5xl font-bold text-green-400 mb-2">{formatUSD(tax.optimized)}</div>
								<div class="text-xl text-green-300">{formatPercent(tax.optimizedRate)} effective rate</div>
							</div>
							<CheckCircle class="w-12 h-12 text-green-400" />
						</div>
					</div>

					<!-- Savings -->
					<div class="bg-gradient-to-r from-green-600/30 to-emerald-600/30 border-2 border-green-400 rounded-xl p-6">
						<div class="flex items-start justify-between">
							<div class="flex-1">
								<div class="text-sm text-gray-300 mb-2">🚀 MONTHLY SAVINGS</div>
								<div class="text-6xl font-bold text-green-300 mb-2">{formatUSD(tax.savings)}</div>
								<div class="text-2xl text-green-400">
									{formatPercent((tax.savings / tax.current) * 100)} reduction
								</div>
							</div>
							<TrendingUp class="w-16 h-16 text-green-400" />
						</div>
					</div>

					<!-- Annual Savings -->
					<div class="bg-gradient-to-r from-yellow-600/30 to-orange-600/30 border-2 border-yellow-400 rounded-xl p-6">
						<div class="text-sm text-gray-300 mb-2">📊 ANNUAL SAVINGS</div>
						<div class="text-6xl font-bold bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent">
							{formatUSD(tax.savings * 12)}
						</div>
						<div class="text-xl text-yellow-400 mt-2">
							Over 12 months with optimized structure
						</div>
					</div>
				</div>
			</div>
		{/if}

		<!-- 7-Day Chart -->
		{#if monthlyVolume && parseFloat(monthlyVolume) > 0}
			<div class="bg-gradient-to-br from-gray-900 to-gray-800 rounded-2xl p-6 border border-green-500/30">
				<h3 class="text-xl font-bold mb-4 text-green-400">
					📈 7-Day Tax Exposure Trend
				</h3>
				<!-- SVG visualization -->
				<svg class="w-full h-64" viewBox="0 0 100 50" preserveAspectRatio="none">
					<!-- Background grid -->
					<defs>
						<pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
							<path d="M 10 0 L 0 0 0 10" fill="none" stroke="#1f2937" stroke-width="0.1" />
						</pattern>
					</defs>
					<rect width="100" height="50" fill="url(#grid)" />

					<!-- Sample trend line -->
					<polyline
						points="0,35 14,28 28,32 42,18 56,25 70,15 84,20 100,12"
						fill="none"
						stroke="#10b981"
						stroke-width="1"
					/>
				</svg>
				<div class="mt-4 text-xs text-gray-500 text-center">
					Based on daily pro-rata calculation of monthly volume
				</div>
			</div>
		{/if}

		<!-- Call to Action -->
		{#if monthlyVolume && parseFloat(monthlyVolume) > 0 && tax.savings > 0}
			<div class="mt-6 bg-gradient-to-r from-green-600 to-emerald-600 rounded-2xl p-8 text-center">
				<h3 class="text-3xl font-bold mb-3">
					Ready to Save {formatUSD(tax.savings * 12)}/year?
				</h3>
				<p class="text-lg mb-4 text-green-100">
					Switch to an optimized structure and reduce your effective tax rate from {formatPercent(
						tax.currentRate
					)} to {formatPercent(tax.optimizedRate)}
				</p>
				<button
					class="bg-white text-green-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-green-50 transition-all transform hover:scale-105"
				>
					Get Custom Tax Strategy →
				</button>
			</div>
		{/if}

		<!-- Footer -->
		<div class="mt-8 text-center text-gray-600 text-sm">
			<p>⚠️ Tax rates are estimates based on 2025 regulations. Consult licensed tax professionals.</p>
			<p class="mt-2">Built for Web3 finance engineers | Live data via CoinGecko</p>
		</div>
	</div>
</div>
